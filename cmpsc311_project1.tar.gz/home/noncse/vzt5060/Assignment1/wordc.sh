#!/bin/bash

initialTime=$(date +%s%N)

if [ "$#" -ne 3 ]; then
	echo "Please enter all three arguments: input-text file output-count file output-runtime file"
	exit 1
fi
if [[ $1 != *.txt  ||  $2 != *.txt ||  $3 != *.txt ]]; then
	echo "Please enter valid txt file names"
	exit 1
fi

tr '-'  NULL  < $1 > outputOneWord2.txt 
gawk '{for (i=1;i<=NF;i++) print $i}' outputOneWord2.txt  > outputOneWord.txt
tr  -cd 'a-zA-Z0-9\n' <  outputOneWord.txt > outputOneWord2.txt
tr 'A-Z' 'a-z' < outputOneWord2.txt > outputOneWord.txt 
sort outputOneWord.txt > outputOneWord2.txt
grep -v -e '^$' outputOneWord2.txt > outputOneWord.txt
uniq -c outputOneWord.txt > $2 

rm -r outputOneWord.txt outputOneWord2.txt

endTime=$(date +%s%N)
runtime=$((endTime - initialTime))
echo "The runtime is: " $runtime > $3
